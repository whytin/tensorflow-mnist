from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import sys
import os.path
import tensorflow as tf
import mnist

from PIL import Image, ImageFilter

flags = tf.app.flags
FLAGS = flags.FLAGS
flags.DEFINE_float('keep_prob', 0.5, 'prob')
flags.DEFINE_integer('hidden1', 32, 'Number of units in hidden layer1')
flags.DEFINE_integer('hidden2', 64, 'Number of units in hidden layer2')
flags.DEFINE_integer('hidden3', 1024, 'Number of units in hidden layer3')


def imageprepare(argv):
    
    im = Image.open(argv).convert('L')
    width = float(im.size[0])
    height = float(im.size[1])
    newImage = Image.new('L', (28,28), (255))

    if width > height:
        
        nheight = int(round(20.0/width*height),0)
        if (nheight == 0):
            nheight = 1

        img = im.resize((20,nheight), Image.ANTIALIAS).filter(ImageFilter.SHARPEN)
        wtop = int(round(((28-nheight)/2),0))
        newImage.paste(img, (4, wtop))

    else:
        nwidth = int(round((20.0/height*width), 0))
        if (nwidth == 0):
            nwidth = 1
        img = im.resize((nwidth,20), Image.ANTIALIAS).filter(ImageFilter.SHARPEN)
        wleft = int(round(((28-nwidth)/2),0))
        newImage.paste(img, (wleft, 4))

    tv = list(newImage.getdata())
    tva = [(255-x)*1.0/255.0 for x in tv]

    return tva

def predict():
    image = imageprepare(sys.argv[1])
    with tf.Graph().as_default():
        sess = tf.Session()
        prediction = mnist.inference(image, FLAGS.hidden1, FLAGS.hidden2, FLAGS.hidden3, FLAGS.keep_prob)
        result = tf.argmax(prediction, 1)
        saver = tf.train.Saver()
        saver.restore(sess, "data/model.ckpt")
        logit = sess.run(result)
        print("The precision: %d" %logit)
    

def main(_):
    predict()

if __name__ == '__main__':
    tf.app.run()
