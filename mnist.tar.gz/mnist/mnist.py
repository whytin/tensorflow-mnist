'''
Build the graph of multilayer convolutional Network
'''

from __future__ import absolute_import, division, print_function

import math

import tensorflow as tf

NUM_CLASSES = 10
IMAGE_SIZE = 28
IMAGE_PIXELS = IMAGE_SIZE * IMAGE_SIZE
FILTER_WIDTH = 5
FC_WIDTH = 7
INPUT_UNITS = 1
BLANK = -1

def conv2d(x, W):
    return tf.nn.conv2d(x,W,strides=[1,1,1,1], padding='SAME')

def max_pool_2x2(x):
    return tf.nn.max_pool(x, ksize=[1,2,2,1], strides=[1,2,2,1], padding='SAME')



def inference(images, hidden1_units, hidden2_units, hidden3_units, keep_prob):
    with tf.name_scope('hidden1'):
	weights = tf.Variable(
                tf.truncated_normal([FILTER_WIDTH, FILTER_WIDTH, INPUT_UNITS, hidden1_units],
                    stddev=1.0 / math.sqrt(float(IMAGE_PIXELS))),
                name='weights')
        biases = tf.Variable(tf.zeros([hidden1_units]), name='biases')
        images = tf.reshape(images, [BLANK, IMAGE_SIZE, IMAGE_SIZE, INPUT_UNITS])
        conv1 = tf.nn.relu(conv2d(images, weights) + biases)
        hidden1 = max_pool_2x2(conv1)

    with tf.name_scope('hidden2'):    	
        weights = tf.Variable(
                tf.truncated_normal([FILTER_WIDTH, FILTER_WIDTH, hidden1_units, hidden2_units],
                    stddev=1.0 / math.sqrt(float(hidden1_units))),
                name='weights')
        biases = tf.Variable(tf.zeros([hidden2_units]), name = 'biases')
        conv2 = tf.nn.relu(conv2d(hidden1, weights) + biases)
        hidden2 = max_pool_2x2(conv2)

    with tf.name_scope('hidden3'):
        weights = tf.Variable(
                tf.truncated_normal([FC_WIDTH*FC_WIDTH*hidden2_units, hidden3_units],
                    stddev=1.0 / math.sqrt(float(hidden2_units))), 
                name='weights')
        biases = tf.Variable(tf.zeros([hidden3_units]), name='biases')
        images_flat = tf.reshape(hidden2, [BLANK, FC_WIDTH*FC_WIDTH*hidden2_units])
        hidden3 = tf.nn.relu(tf.matmul(images_flat, weights) + biases)

    with tf.name_scope('softmax'):
        drop = tf.nn.dropout(hidden3, keep_prob)
        weights = tf.Variable(
                tf.truncated_normal([hidden3_units, NUM_CLASSES],
                    stddev=1.0 / math.sqrt(hidden3_units)),
                name = 'weights')
        biases = tf.Variable(tf.zeros(NUM_CLASSES), name='biases')
        logits = tf.matmul(hidden3, weights) + biases

    return logits

def loss(logits, labels):
    labels = tf.to_int64(labels)
    cross_entropy = tf.nn.sparse_softmax_cross_entropy_with_logits(logits, labels, name='xentropy')
    loss = tf.reduce_mean(cross_entropy, name='xentropy_mean')
    return loss

def training(loss, learning_rate):
    tf.scalar_summary(loss.op.name, loss)
    optimizer = tf.train.AdamOptimizer(learning_rate)
    global_step = tf.Variable(0, name='global_step', trainable=False)
    train_op = optimizer.minimize(loss, global_step=global_step)
    return train_op

def evaluation(logits, labels):
    correct = tf.nn.in_top_k(logits, labels, 1)
    return tf.reduce_sum(tf.cast(correct, tf.int32))



