# tensorflow-mnist
some mnist train projects
