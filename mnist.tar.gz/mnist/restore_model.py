import tensorflow as tf
v1 = tf.Variable(0.0, name="hidden1/weights")
v2 = tf.Variable(0.0, name="hidden2/weights")
# Add ops to save and restore all the variables.
saver = tf.train.Saver()

# Later, launch the model, use the saver to restore variables from disk, and
# do some work with the model.
with tf.Session() as sess:
    new_saver = tf.train.import_meta_graph("data/model.ckpt.meta")
    new_saver.restore(sess, "data/model.ckpt")
    all_vars = tf.trainable_variables()
    for v in all_vars:
        print(v.name)
    print("Model restored.")
            # Do some work with the model
