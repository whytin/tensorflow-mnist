from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os.path
import time
import math

from six.moves import xrange
import tensorflow as tf
import numpy as np

import shelve

s = shelve.open('urban.db')
tr_features = s['tr_features']
tr_labels = s['tr_labels']
indices = np.random.rand(len(tr_labels)) < 0.3
#ts_features = s['ts_features']
#ts_labels = s['ts_labels']
ts_features = tr_features[indices]
ts_labels = tr_labels[indices]


batch_size = 200
n_dim = tr_features.shape[1]
n_classes = 10
flags = tf.app.flags
FLAGS = flags.FLAGS
flags.DEFINE_float('learning_rate', 0.01, 'Initial learning rate')
flags.DEFINE_integer('max_steps', 10000, 'Number of training steps')
flags.DEFINE_integer('hidden1', 280, 'Number of units in hidden1')
flags.DEFINE_integer('hidden2', 300, 'Number of units in hidden2')
flags.DEFINE_float('stddev', 1/math.sqrt(n_dim), 'stddev')
flags.DEFINE_string('train_dir', 'data', 'The path of storing the model')

def placeholder_inputs():
    sounds_placeholder = tf.placeholder(tf.float32, [None, n_dim])
    labels_placeholder = tf.placeholder(tf.float32, [None, n_classes])
    return sounds_placeholder, labels_placeholder

def inference(sounds, hidden1_units, hidden2_units, stddev):
    with tf.name_scope('hidden1'):
        weights = tf.Variable(tf.random_normal([n_dim, hidden1_units], mean=0, stddev=stddev), name='weights')
        biases = tf.Variable(tf.random_normal([hidden1_units]), name='biases')
        hidden1 = tf.nn.tanh(tf.matmul(sounds,weights) + biases)

    with tf.name_scope('hidden2'):
        weights = tf.Variable(tf.random_normal([hidden1_units, hidden2_units], mean=0, stddev=stddev), name='weights')
        biases = tf.Variable(tf.random_normal([hidden2_units], mean=0, stddev=stddev), name='biases')
        hidden2 = tf.nn.sigmoid(tf.matmul(hidden1, weights) + biases)

    with tf.name_scope('softmax'):
        weights = tf.Variable(tf.random_normal([hidden2_units, n_classes], mean=0, stddev=stddev), name='weights')
        biases = tf.Variable(tf.random_normal([n_classes], mean=0, stddev=stddev), name='biases')
        logits = tf.nn.softmax(tf.matmul(hidden2, weights) + biases)

    return logits

def cost(logits, labels):
    cost = tf.reduce_mean(-tf.reduce_sum(labels * tf.log(logits), reduction_indices=[1]), name='loss')
    return cost

def training(loss, learning_rate):
    tf.summary.scalar('loss', loss)
    optimizer = tf.train.GradientDescentOptimizer(learning_rate)
    global_step = tf.Variable(0, name='global_step', trainable=False)
    train_op = optimizer.minimize(loss, global_step=global_step)
    return train_op

def evaluation(logits, labels):
    correct = tf.equal(tf.argmax(logits, 1), tf.argmax(labels, 1))
    accuracy = tf.reduce_mean(tf.cast(correct, tf.float32))
    return accuracy

def do_eval():
    true_count = 0


def run_training():
    with tf.Graph().as_default():
        sounds_placeholder, labels_placeholder = placeholder_inputs()
        logits = inference(sounds_placeholder, FLAGS.hidden1, FLAGS.hidden2, FLAGS.stddev)
        loss = cost(logits, labels_placeholder)
        train_op = training(loss, FLAGS.learning_rate)
        accuracy = evaluation(logits, labels_placeholder)
        summary = tf.summary.merge_all()
        init = tf.global_variables_initializer()
        saver = tf.train.Saver()
        sess = tf.Session()
        summary_writer = tf.summary.FileWriter(FLAGS.train_dir, sess.graph)
        sess.run(init)
        for step in xrange(FLAGS.max_steps + 1):
            start_time = time.time()
#            offset = (step *batch_size) % (tr_labels.shape[0]-batch_size)
#            batch_x = tr_features[offset:(offset+batch_size), :]
#            batch_y = tr_labels[offset:(offset+batch_size), :]
            _, loss_value = sess.run([train_op, loss], feed_dict={sounds_placeholder:tr_features, labels_placeholder:tr_labels})
            duration = time.time() - start_time

            if step % 100 == 0:
                print('Step %d: loss = %.2f (%.3f sec)' %(step,loss_value, duration))
                summary_str = sess.run(summary, feed_dict={sounds_placeholder:tr_features, labels_placeholder:tr_labels})
                summary_writer.add_summary(summary_str, step)
                summary_writer.flush()

            if step % 1000 == 0:
                checkpoint_file = os.path.join(FLAGS.train_dir, 'model.ckpt')
                saver.save(sess, checkpoint_file, global_step=step)
                eval_accuracy = sess.run(accuracy, feed_dict={sounds_placeholder:ts_features, labels_placeholder:ts_labels})
                print('Validation Data Eval:', eval_accuracy)


def main(_):
    run_training()

if __name__ == '__main__':
    tf.app.run()







