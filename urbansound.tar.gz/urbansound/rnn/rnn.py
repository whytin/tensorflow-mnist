from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os.path
import time
import math
import numpy as np

from six.moves import xrange
import tensorflow as tf
from tensorflow.python.ops import rnn

import shelve

s = shelve.open('urban.db')
tr_features = s['tr_features']
tr_labels = s['tr_labels']
#t_features = s['ts_features']
#t_labels = s['ts_labels']
indices = np.random.rand(len(tr_labels)) < 0.3
ts_features = tr_features[indices]
ts_labels = tr_labels[indices]

n_input = 20
n_steps = 41
n_classes = 10
flags = tf.app.flags
FLAGS = flags.FLAGS
flags.DEFINE_float('learning_rate', 1e-4, 'Initial learning rate')
flags.DEFINE_integer('batch_size', 1000, 'batch sizes for training')
flags.DEFINE_integer('max_steps', 3000, 'Number of training steps')
flags.DEFINE_integer('hidden', 300, 'Number of units in hidden')
flags.DEFINE_string('train_dir', 'data', 'The path of storing the model')

def placeholder_inputs():
    sounds_placeholder = tf.placeholder(tf.float32, [None, n_input, n_steps])
    labels_placeholder = tf.placeholder(tf.float32, [None, n_classes])
    return sounds_placeholder, labels_placeholder

def RNN(sounds, weights, biases, hidden_units):
    cell = tf.contrib.rnn.LSTMCell(hidden_units, state_is_tuple = True)
    cell = tf.contrib.rnn.MultiRNNCell([cell] * 2, state_is_tuple = True)
    output, state = tf.nn.dynamic_rnn(cell, sounds, dtype=tf.float32)
    output = tf.transpose(output, [1, 0, 2])
    last = tf.gather(output, int(output.get_shape()[0]) - 1)
    return tf.nn.softmax(tf.matmul(last, weights) + biases)


def inference(sounds, hidden_units):
    with tf.name_scope('rnn'):
        weights = tf.Variable(tf.random_normal([hidden_units, n_classes]), name='weights')
        biases = tf.Variable(tf.random_normal([n_classes]), name='biases')
        logits = RNN(sounds, weights, biases, hidden_units)

    return logits

def cost(logits, labels):
    cost = tf.reduce_mean(-tf.reduce_sum(labels * tf.log(tf.clip_by_value(logits, 1e-10, 1.0)), reduction_indices=[1]), name='loss')
    return cost

def training(loss, learning_rate):
    tf.summary.scalar('loss', loss)
    optimizer = tf.train.AdamOptimizer(learning_rate)
    global_step = tf.Variable(0, name='global_step', trainable=False)
    train_op = optimizer.minimize(loss, global_step=global_step)
    return train_op

def evaluation(logits, labels):
    correct = tf.equal(tf.argmax(logits, 1), tf.argmax(labels, 1))
    accuracy = tf.reduce_mean(tf.cast(correct, tf.float32))
    return accuracy

def do_eval():
    true_count = 0


def run_training():
    with tf.Graph().as_default():
        sounds_placeholder, labels_placeholder = placeholder_inputs()
        logits = inference(sounds_placeholder, FLAGS.hidden)
        loss = cost(logits, labels_placeholder)
        train_op = training(loss, FLAGS.learning_rate)
        accuracy = evaluation(logits, labels_placeholder)
        summary = tf.summary.merge_all()
        init = tf.global_variables_initializer()
        saver = tf.train.Saver()
        sess = tf.Session()
        summary_writer = tf.summary.FileWriter(FLAGS.train_dir, sess.graph)
        sess.run(init)
        for step in xrange(FLAGS.max_steps + 1):
            start_time = time.time()
            offset = (step*FLAGS.batch_size)%(tr_labels.shape[0] - FLAGS.batch_size)
            batch_x = tr_features[offset:(offset + FLAGS.batch_size), :, :]
            batch_y = tr_labels[offset:(offset + FLAGS.batch_size), :]
            _, loss_value = sess.run([train_op, loss], feed_dict={sounds_placeholder:batch_x, labels_placeholder:batch_y})
            duration = time.time() - start_time

            if step % 100 == 0:
                print('Step %d: loss = %.2f (%.3f sec)' %(step,loss_value, duration))
                summary_str = sess.run(summary, feed_dict={sounds_placeholder:tr_features, labels_placeholder:tr_labels})
                summary_writer.add_summary(summary_str, step)
                summary_writer.flush()

            if step % 1000 == 0:
                checkpoint_file = os.path.join(FLAGS.train_dir, 'model.ckpt')
                saver.save(sess, checkpoint_file, global_step = step)

                eval_accuracy = sess.run(accuracy, feed_dict={sounds_placeholder:ts_features, labels_placeholder:ts_labels})
                print('Validation Data Eval:', eval_accuracy)


def main(_):
    run_training()

if __name__ == '__main__':
    tf.app.run()







