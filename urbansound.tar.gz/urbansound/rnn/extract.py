import glob
import os
import librosa
import numpy as np
import shelve

def windows(data, window_size):
    start = 0
    while start < len(data):
        yield start, start + window_size
        start += (window_size / 2)

def extract_features(parent_dir, sub_dirs, file_ext="*.wav",bands=20, frames=41):
    window_size = 512 * (frames - 1)
    mfccs = []
    labels = []
    for l, sub_dir in enumerate(sub_dirs):
        for fn in glob.glob(os.path.join(parent_dir, sub_dir, file_ext)):
            try:
                sound_clip, s = librosa.load(fn)
            except Exception as e:
                print("Error in encountered the file :", fn)
                continue
            
            label = fn.split('/')[7].split('-')[1]
            print fn
            for (start, end) in windows(sound_clip, window_size):
                if (len(sound_clip[start:end]) == window_size):
                    signal = sound_clip[start:end]
                    mfcc = librosa.feature.mfcc(y=signal, sr=s, n_mfcc= bands).T.flatten()[:, np.newaxis].T
                    mfccs.append(mfcc)
                    labels.append(label)

    features = np.asarray(mfccs).reshape(len(mfccs), bands, frames)
    return np.array(features), np.array(labels, dtype=np.int)


def one_hot_encode(labels):
    n_labels = len(labels)
    n_unique_labels = len(np.unique(labels))
    one_hot_encode = np.zeros((n_labels, n_unique_labels))
    one_hot_encode[np.arange(n_labels), labels] = 1
    return one_hot_encode

parent_dir = '/home/whytin/datasets/UrbanSound8K/audio/'
tr_sub_dirs = ['fold1', 'fold2', 'fold4', 'fold6', 'fold8', 'fold9', 'fold10']
tr_features, tr_labels = extract_features(parent_dir, tr_sub_dirs)
tr_labels = one_hot_encode(tr_labels)

ts_sub_dirs = ['fold3', 'fold5', 'fold7']
ts_features, ts_labels = extract_features(parent_dir, ts_sub_dirs)
ts_labels = one_hot_encode(ts_labels)


s = shelve.open('urban.db')
s['tr_features'] = tr_features
s['tr_labels'] = tr_labels
s['ts_features'] = ts_features
s['ts_labels'] = ts_labels
s.close()
